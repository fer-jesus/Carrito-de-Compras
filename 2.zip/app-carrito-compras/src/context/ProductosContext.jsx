import { createContext } from "react";


export const ProductosContext = createContext()